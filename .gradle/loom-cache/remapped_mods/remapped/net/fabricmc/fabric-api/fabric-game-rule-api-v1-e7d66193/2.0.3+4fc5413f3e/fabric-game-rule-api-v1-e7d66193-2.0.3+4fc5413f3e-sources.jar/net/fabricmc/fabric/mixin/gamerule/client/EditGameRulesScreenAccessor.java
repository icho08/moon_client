/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.gamerule.client;

import net.minecraft.class_1928;
import net.minecraft.class_5235;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_5235.class)
public interface EditGameRulesScreenAccessor {
	@Invoker("clearInvalid")
	void callMarkValid(class_5235.class_5240 ruleWidget);

	@Invoker("markInvalid")
	void callMarkInvalid(class_5235.class_5240 ruleWidget);

	@Accessor("gameRules")
	class_1928 getGameRules();
}
