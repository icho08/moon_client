/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.particle;

import net.minecraft.class_2338;
import net.minecraft.class_2388;
import net.minecraft.class_2396;
import net.minecraft.class_2680;
import org.jspecify.annotations.Nullable;

public final class BlockStateParticleEffectFactoryImpl {
	private BlockStateParticleEffectFactoryImpl() {
	}

	public static class_2388 create(class_2396<class_2388> type, class_2680 blockState, @Nullable class_2338 blockPos) {
		class_2388 effect = new class_2388(type, blockState);
		((BlockStateParticleEffectExtension) effect).fabric_setBlockPos(blockPos);
		return effect;
	}
}
