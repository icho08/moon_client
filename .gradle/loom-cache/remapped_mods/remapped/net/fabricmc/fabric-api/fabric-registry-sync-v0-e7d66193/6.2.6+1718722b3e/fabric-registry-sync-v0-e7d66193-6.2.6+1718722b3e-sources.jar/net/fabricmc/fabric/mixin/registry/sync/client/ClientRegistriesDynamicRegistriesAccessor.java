/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.registry.sync.client;

import java.util.List;
import java.util.Map;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7782;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(targets = "net.minecraft.client.multiplayer.RegistryDataCollector$ContentsCollector")
public interface ClientRegistriesDynamicRegistriesAccessor {
	@Accessor("elements")
	Map<class_5321<? extends class_2378<?>>, List<class_7782.class_9176>> getDynamicRegistries();
}
